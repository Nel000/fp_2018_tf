import pygame
from pygame import mixer

pygame.mixer.pre_init(44100, 16, 2, 4026)
pygame.init()
mixer.init()

size = (600, 600)

walkRight = [pygame.image.load('mainchar.png')]
walkLeft = [pygame.image.load('mainchar.png')]
walkUp = [pygame.image.load('mainchar.png')]
walkDown = [pygame.image.load('mainchar.png')]
bg = pygame.image.load('mapa.jpg')
char = pygame.image.load('mainchar.png')

screen = pygame.display.set_mode(size)

pygame.display.set_caption ("JOGO DO MONSTRO")

clock = pygame.time.Clock()

arrowSound = pygame.mixer.Sound("bullet.wav")

hitSound = pygame.mixer.Sound("OOF.wav")

music = pygame.mixer.music.load("background.mp3")
pygame.mixer.music.set_volume(0.15)
pygame.mixer.music.play(-1, 0.0)

class player(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 15
        self.left = False
        self.right = False
        self.up = False
        self.down = False
        self.walkCount = 0
        self.standing = True
        self.hitbox = (self.x + 20, self.y, 28, 60)
        self.health = 0

    def draw(self,screen):
        if self.walkCount + 1 >= 30:
            self.walkCount = 0
        if not(self.standing):
            if self.left:
                screen.blit(walkLeft[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            if self.right:
                screen.blit(walkRight[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            if self.up:
                screen.blit(walkUp[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
            if self.down:
                screen.blit(walkDown[self.walkCount//3], (self.x,self.y))
                self.walkCount += 1
        else:
            if self.right:
                screen.blit(walkRight[0], (self.x, self.y))
            else:
                screen.blit(walkLeft[0], (self.x, self.y))
        #pygame.draw.rect(screen, (255, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
        #pygame.draw.rect(screen, (0, 128, 0), (self.hitbox[0], self.hitbox[1] - 20, 50 - (5 * (10 - self.health)), 10))
        self.hitbox = (self.x + 20, self.y, 28, 60)
        #pygame.draw.rect(screen, (255,0,0), self.hitbox, 2)

    def hit(self):
        self.x = 265
        self.y = 50
        self.walkCount = 0
        font1 = pygame.font.SysFont('arial', 35)
        text = font1.render('YOU DIED, press a key to continue', 1, (255,0,0))
        screen.blit(text, (300 - (text.get_width()/2), 200))
        pygame.display.update()
        waiting = True
        while waiting:
            clock.tick(30)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                if event.type == pygame.KEYDOWN:
                    waiting = False

    def collect(self):
        self.x = 500
        self.y = 300
        self.walkCount = 0
        font1 = pygame.font.SysFont('arial', 30)
        text = font1.render('YOU GOT THE GOLD, now head to the exit', 1, (255,0,0))
        screen.blit(text, (300 - (text.get_width()/2), 200))
        pygame.display.update()
        i = 0
        while i < 10:
            pygame.time.delay(100)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 301
                    pygame.quit()

    def getOut(self):
        self.x = 0
        self.y = 0
        self.walkCount = 0
        font1 = pygame.font.SysFont('arial', 35)
        text = font1.render('VICTORY ROYALE (you can quit now)', 1, (255, 0, 0))
        screen.blit(text, (300 - (text.get_width() / 2), 200))
        pygame.display.update()
        waiting = True
        while waiting:
            clock.tick(30)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()

class projectile(object):
    def __init__(self, x, y, radius, color, facing):
        self.x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 8 * facing


    def draw(self, screen):
        pygame.draw.circle(screen, self.color, (self.x, self.y), self.radius)

class collectable(object):
    exist = [pygame.image.load('treasure.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.presence = 0
        self.vel = 0
        self.hitbox = (self.x, self.y, 100, 100)
        self.visible = True

    def draw(self, screen):
        if self.visible:
            if self.presence + 1 <= 33:
                self.presence = 0

            if self.vel > 0:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            else:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            self.hitbox = (self.x, self.y, 100, 100)
            #pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

class door(object):
    exist = [pygame.image.load('exit.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.presence = 0
        self.vel = 0
        self.hitbox = (self.x, self.y, 5, 32)
        self.visible = True

    def draw(self, screen):
        if self.visible:
            if self.presence + 1 <= 33:
                self.presence = 0

            if self.vel > 0:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            else:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            self.hitbox = (self.x, self.y, 5, 32)
            #pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

class hole(object):
    exist = [pygame.image.load('well.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.presence = 0
        self.vel = 0
        self.hitbox = (self.x, self.y, 100, 100)
        self.visible = True

    def draw(self, screen):
        if self.visible:
            if self.presence + 1 <= 33:
                self.presence = 0

            if self.vel > 0:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            else:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            self.hitbox = (self.x, self.y, 100, 100)
            #pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

class secondhole(object):
    exist = [pygame.image.load('well.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.presence = 0
        self.vel = 0
        self.hitbox = (self.x, self.y, 100, 100)
        self.visible = True

    def draw(self, screen):
        if self.visible:
            if self.presence + 1 <= 33:
                self.presence = 0

            if self.vel > 0:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            else:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            self.hitbox = (self.x, self.y, 100, 100)
            #pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

class thirdhole(object):
    exist = [pygame.image.load('well.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.presence = 0
        self.vel = 0
        self.hitbox = (self.x, self.y, 100, 100)
        self.visible = True

    def draw(self, screen):
        if self.visible:
            if self.presence + 1 <= 33:
                self.presence = 0

            if self.vel > 0:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            else:
                screen.blit(self.exist[self.presence // 3], (self.x, self.y))
                self.presence += 1
            self.hitbox = (self.x, self.y, 100, 100)
            #pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

class enemy(object):
    walkRight = [pygame.image.load('bicho.png')]
    walkLeft = [pygame.image.load('bicho.png')]
    walkUp = [pygame.image.load('bicho.png')]
    walkDown = [pygame.image.load('bicho.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, y, end]
        self.walkCount = 0
        self.vel = 25
        self.hitbox = (self.x, self.y, 120, 120)
        self.health = 10
        self.visible = True

    def draw(self, screen):
        self.move()
        if self.visible:
            if self.walkCount + 1 <= 33:
                self.walkCount = 0

            if self.vel > 0:
                screen.blit(self.walkRight[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            else:
                screen.blit(self.walkLeft[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            pygame.draw.rect(screen, (255, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 50, 10))
            pygame.draw.rect(screen, (0, 128, 0), (self.hitbox[0], self.hitbox[1] - 20, 50 - (5 * (10 - self.health)), 10))
            self.hitbox = (self.x, self.y, 120, 120)
            # pygame.draw.rect(screen, (255, 0, 0), self.hitbox, 2)

    def move(self):
        if self.vel > 0:
            if self.x + self.vel < self.path[1]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.x += self.vel
                self.walkCount = 0
        else:
            if self.x - self.vel > self.path[0]:
                self.x += self.vel
            else:
                self.vel = self.vel * -1
                self.x += self.vel
                self.walkCount = 0

    def hit(self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False
            font1 = pygame.font.SysFont('arial', 70)
            text = font1.render('MONSTER SLAIN', 1, (255,0,0))
            screen.blit(text, (300 - (text.get_width()/2), 200))
            pygame.display.update()
            i = 0
            while i < 10:
                pygame.time.delay(50)
                i += 1
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        i = 301
                        pygame.quit()

def redrawGameWindow():
    screen.blit(bg, (0,0))
    man.draw(screen)
    monster.draw(screen)
    treasure.draw(screen)
    exit.draw(screen)
    well.draw(screen)
    secondwell.draw(screen)
    thirdwell.draw(screen)
    for arrow in arrows:
        arrow.draw(screen)

    pygame.display.update()

font = pygame.font.SysFont('arial', 30)
man = player(265, 50, 64, 64)
monster = enemy(50, 420, 128, 128, 450)
treasure = collectable(470, 270, 128, 128, 450)
exit = door(30, 550, 5, 32, 450)
well = hole(50, 20, 128, 128, 450)
secondwell = secondhole(450, 150, 128, 128, 450)
thirdwell = thirdhole(350, 270, 128, 128, 450)
arrows = []
run = True
while run:

    clock.tick(30)

    if monster.visible == True:
        if man.hitbox[1] < monster.hitbox[1] + monster.hitbox[3] and man.hitbox[1] + man.hitbox[3] > monster.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > monster.hitbox[0] and man.hitbox[0] < monster.hitbox[0] + monster.hitbox[2]:
                man.hit()

    if well.visible == True:
        if man.hitbox[1] < well.hitbox[1] + well.hitbox[3] and man.hitbox[1] + man.hitbox[3] > well.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > well.hitbox[0] and man.hitbox[0] < well.hitbox[0] + well.hitbox[2]:
                man.hit()

    if secondwell.visible == True:
        if man.hitbox[1] < secondwell.hitbox[1] + secondwell.hitbox[3] and man.hitbox[1] + man.hitbox[3] > secondwell.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > secondwell.hitbox[0] and man.hitbox[0] < secondwell.hitbox[0] + secondwell.hitbox[2]:
                man.hit()

    if thirdwell.visible == True:
        if man.hitbox[1] < thirdwell.hitbox[1] + thirdwell.hitbox[3] and man.hitbox[1] + man.hitbox[3] > thirdwell.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > thirdwell.hitbox[0] and man.hitbox[0] < thirdwell.hitbox[0] + thirdwell.hitbox[2]:
                man.hit()

    if treasure.visible == True:
        if man.hitbox[1] < treasure.hitbox[1] + treasure.hitbox[3] and man.hitbox[1] + man.hitbox[3] > treasure.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > treasure.hitbox[0] and man.hitbox[0] < treasure.hitbox[0] + treasure.hitbox[2]:
                man.collect()
                treasure.visible = False

    if exit.visible == True:
        if man.hitbox[1] < exit.hitbox[1] + exit.hitbox[3] and man.hitbox[1] + man.hitbox[3] > exit.hitbox[1]:
            if man.hitbox[0] + man.hitbox[2] > exit.hitbox[0] and man.hitbox[0] < exit.hitbox[0] + exit.hitbox[2]:
                man.getOut()

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            run = False

    for arrow in arrows:
        if arrow.y - arrow.radius < monster.hitbox[1] + monster.hitbox[3] and arrow.y + arrow.radius > monster.hitbox[1]:
            if arrow.x + arrow.radius > monster.hitbox[0] and arrow.x - arrow.radius < monster.hitbox[0] + monster.hitbox[2]:
                hitSound.play()
                monster.hit()
                arrows.pop(arrows.index(arrow))

        if arrow.x < 600 and arrow.x > 0:
            arrow.x += arrow.vel
        else:
            arrows.pop(arrows.index(arrow))

    keys = pygame.key.get_pressed()

    if keys[pygame.K_SPACE]:
        arrowSound.play()
        if man.left:
            facing = -1
        if man.right:
            facing = -1
        if man.up:
            facing = -1
        if man.down:
            facing = -1
        else:
            facing = 1

        if len(arrows) < 1:
            arrows.append(projectile(round(man.x + man.width//2), round(man.y + man.height//2), 6, (255, 255, 255), facing))

    if keys[pygame.K_LEFT] and man.x > man.vel:
        man.x -= man.vel
        man.standing = False
    if keys[pygame.K_RIGHT] and man.x < 600 - man.width - man.vel:
        man.x += man.vel
        man.standing = False
    if keys[pygame.K_UP] and man.y > man.vel:
        man.y -= man.vel
        man.standing = False
    if keys[pygame.K_DOWN] and man.y < 600 - man.height - man.vel:
        man.y += man.vel
        man.standing = False
    else:
        man.standing = True
        man.walkCount = 0

    redrawGameWindow()

pygame.quit()
